class Test {
    public static void main(String[] args) {
        FFClient c = new FFClient();
        c.run();
    }
}
