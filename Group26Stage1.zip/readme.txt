enter ds-sim;
run "make; ./tests.sh myclient";