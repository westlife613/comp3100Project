class Test {
    public static void main(String[] args) {
        WFClient c = new WFClient();
        c.run();
    }
}
